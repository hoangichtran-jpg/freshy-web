export {
  PosManagementPage,
} from "./pages";